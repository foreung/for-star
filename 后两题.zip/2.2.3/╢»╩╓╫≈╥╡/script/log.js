function log(){
    let pas = document.getElementById("password_log").value;
    let name = document.getElementById("name_log").value;

    if(localStorage.length == 0){
        alert("亲你还没注册呢")
    }else{
       let namedate=[]
       let pasdata = []
       let iddata = []

       for (let i = 0; i < localStorage.length; i++) {
        let key = localStorage.key(i)
        let keydata = localStorage.getItem(key);
        let keyinfo = JSON.parse(keydata);

        pasdata[i] = keyinfo.pas
		iddata[i] = keyinfo.id
        namedate[i] = keyinfo.name
       }
       if(namedate.indexOf(name)<0){
        alert("此账号未注册")
       }else{
        let index = namedate.indexOf(name)
        if(pasdata[index] != pas){
            alert("密码错误")
        }else{
            alert("登录成功")
        }
       }  
    }
}
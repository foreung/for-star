var btn_register= document.getElementById("btn_register")
var mask_one=document.getElementById("mask_one")
var back_one=document.getElementById("back_one")

btn_register.onclick=function(){
  mask_one.style.display="block"
}

back_one.onclick=function(){
  mask_one.style.display="none"
}

var btn_log= document.getElementById("btn_log")
var mask_two=document.getElementById("mask_two")
var back_two=document.getElementById("back_two")

btn_log.onclick=function(){
  mask_two.style.display="block"
}

back_two.onclick=function(){
  mask_two.style.display="none"
}
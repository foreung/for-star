function register(){
    let name = document.getElementById("name_register").value;
    console.log(name)
    let pas = document.getElementById("password_register").value;
    console.log(pas)
    let affpas = document.getElementById("affirmPassword_register").value;
    console.log(affpas)
/**获取输入框的信息**/
    if (localStorage.length == 0){/**判断本地是否储存了信息**/
      if(pas != affpas){
        alert("两次输入的密码不相同")
      }else{
        let dataLength = localStorage.length/**用现在注册的数目来作为这个用户名独有的id**/
        let data={}/**创建一个对象来储存用户信息**/
        data.name= name;
        data.pas=pas;
        data.id=dataLength;
        let info = JSON.stringify(data)/**转换成字符串**/
        localStorage.setItem("key"+dataLength,info)
        alert("注册成功！请返回登录界面登录！")
      }
    }else{
        for (let i = 0; i < localStorage.length; i++){/**为了之后判断用户名是否重复**/
        let key = localStorage.key(i)/**之前在对象中储存了id的**/
        let keydata = localStorage.getItem(key);
        let keyinfo = JSON.parse(keydata)
        if(keyinfo.name==name){
            alert("该用户名已注册")
            break;
        }else if(pas!=affpas){
            alert("两次输入的密码不相同")
            break;
        }else{/**和之前一致了**/
            let dataLength = localStorage.length
        let data={}
        data.name= name;
        data.pas=pas;
        data.id=dataLength;
        let info = JSON.stringify(data)
        localStorage.setItem("key"+dataLength,info)
        alert("注册成功！请返回登录界面登录！")
        break;
        }
        }
    }
  };